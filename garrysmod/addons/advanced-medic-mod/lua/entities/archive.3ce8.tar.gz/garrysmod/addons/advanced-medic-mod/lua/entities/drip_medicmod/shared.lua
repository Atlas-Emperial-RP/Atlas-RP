ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Drip"
ENT.Category = "Medic Mod"
ENT.Author = "Venatuss"
ENT.Spawnable = true