return {
	DefaultEnabled = true,
	Name = "Billy's Whitelist",
	Category = GAS.MODULE_CATEGORY_PLAYER_MANAGEMENT,
	Wiki = "https://gmodsto.re/bwhitelist-wiki",
	Icon = "icon16/vcard_edit.png",
	DarkRP = true,
	GmodStore = "6017",
	License = '{"licensee":"76561198165273585","keys":{"xeon-de":"LXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX","xeon-us":"LXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"}}'
}