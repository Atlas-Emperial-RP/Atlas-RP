ENT.Base = "base_point"

ENT.Type = "point"
ENT.Spawnable = false
ENT.DoNotDuplicate = true