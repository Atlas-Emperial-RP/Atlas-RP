return {
	["en"] = "english",
	["en-PT"] = "english",
	["ru"] = "russian",
	["fr"] = "french",
	["de"] = "german",
}