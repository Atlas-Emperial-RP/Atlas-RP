return {
	Version    = "4.1.0",
	SV_Version = "3.3.0",
	SteamID64  = "76561198112485755",
	License    = 'bc2383bcfd807c89d304a093b3ac9c003e25277996a436fece0ae032bd6a19ba',
}